export const handler = () => {
    console.log('Hello world!')
}